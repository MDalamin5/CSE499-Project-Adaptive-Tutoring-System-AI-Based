# Adaptive AI Math Tutor

This application is an enhanced math tutoring system that uses adaptive prompts to provide personalized guidance to students based on their responses. The system analyzes student responses to determine if they are correct, partially correct, or incorrect, and then generates adaptive prompts to guide the AI tutor in providing more targeted assistance.

## Features

- **Interactive Math Tutoring**: Provides hints and guiding questions for high school algebra problems
- **Sentiment Analysis**: Classifies student responses as correct, partially correct, or incorrect
- **Adaptive Prompting**: Generates customized prompts based on the student's understanding level
- **Real-time Feedback**: Displays sentiment analysis and adaptive prompts in the sidebar
- **Streamlit UI**: User-friendly interface for student-tutor interaction

## Requirements

- Python 3.7+
- Streamlit
- LangChain
- Groq API key (set as environment variable `GROQ_API_KEY`)
- dotenv

## Installation

1. Clone this repository or download the code
2. Install the required packages:
   ```
   pip install streamlit langchain-groq langchain-core langchain-community pydantic python-dotenv
   ```
3. Create a `.env` file in the project directory with your Groq API key:
   ```
   GROQ_API_KEY=your_api_key_here
   ```

## Usage

1. Run the application:
   ```
   streamlit run adaptive_math_tutor.py
   ```
2. Enter a math problem in the chat input
3. The AI tutor will provide a hint and a guiding question
4. Respond to the hint with your attempt at solving the step
5. The system will analyze your response and adapt its guidance accordingly
6. View the sentiment analysis and adaptive prompt in the sidebar

## How It Works

1. **Initial Problem Submission**: Student submits a math problem
2. **Hint Generation**: AI tutor provides a hint and guiding question
3. **Response Analysis**: System analyzes the student's response to determine correctness
4. **Adaptive Prompt Generation**: System generates a customized prompt based on the analysis
5. **Enhanced Guidance**: AI tutor uses the adaptive prompt to provide more targeted assistance

## System Components

### Sentiment Analysis

The system uses a structured output parser to classify student responses into three categories:
- **Correct**: Student has correctly understood and applied the concept
- **Partially Correct**: Student has some understanding but with misconceptions
- **Incorrect**: Student has fundamental misunderstandings

### Adaptive Prompt Generation

Based on the sentiment analysis, the system generates different types of adaptive prompts:
- **For Correct Responses**: Acknowledges understanding and encourages moving to the next step
- **For Partially Correct Responses**: Identifies specific misconceptions and suggests targeted hints
- **For Incorrect Responses**: Addresses fundamental misunderstandings with more basic hints

### Integration with Math Tutor

The adaptive prompts are integrated with the base tutoring system to create a dynamic system prompt that guides the AI tutor in providing personalized assistance.

## Testing

To test the application:
1. Start with simple algebra problems (e.g., solving linear equations)
2. Try different types of responses to see how the system adapts:
   - Correct answers
   - Partially correct answers with minor errors
   - Completely incorrect approaches
3. Observe the sentiment analysis and adaptive prompts in the sidebar

## Troubleshooting

- **API Key Issues**: Ensure your Groq API key is correctly set in the `.env` file
- **Model Availability**: If you encounter model availability issues, try changing the model in the `setup_llm` function
- **Response Format Errors**: If the structured output parsing fails, check the console for error messages

## Extending the System

The adaptive prompt system can be extended in several ways:
- Adding more detailed sentiment categories
- Implementing different adaptive strategies for various math topics
- Incorporating a progress tracking system
- Adding explanations of common misconceptions

# Adaptive Math Tutor - Deployment Guide

This guide provides instructions for deploying the Adaptive Math Tutor application to various hosting platforms.

## Application Structure

The application consists of the following key files:

- `streamlit_app.py` - Main application entry point with setup and configuration
- `pages/adaptive_math_tutor.py` - The core math tutor implementation
- `pages/home.py` - Welcome page with instructions
- `requirements.txt` - Dependencies for installation
- `Procfile` - Process definition for platforms like Heroku
- `runtime.txt` - Python version specification
- `.streamlit/config.toml` - Streamlit configuration

## Deployment Options

### Option 1: Streamlit Cloud (Recommended)

Streamlit Cloud is the easiest way to deploy Streamlit applications with minimal configuration.

1. Create an account at [https://streamlit.io/cloud](https://streamlit.io/cloud)
2. Connect your GitHub account
3. Create a new GitHub repository and upload all the application files
4. In Streamlit Cloud, deploy your app by selecting the repository
5. Set the main file as `streamlit_app.py`
6. Add the `GROQ_API_KEY` as a secret in the Streamlit Cloud dashboard:
   - Go to Advanced Settings > Secrets
   - Add a new secret with the key `GROQ_API_KEY` and your API key as the value

### Option 2: Heroku

Heroku is a flexible platform that can host Streamlit applications.

1. Create a Heroku account at [https://heroku.com](https://heroku.com)
2. Install the [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)
3. Initialize a git repository with the application files:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   ```
4. Create a new Heroku app:
   ```
   heroku create your-app-name
   ```
5. Set the API key:
   ```
   heroku config:set GROQ_API_KEY=your-api-key
   ```
6. Deploy the application:
   ```
   git push heroku main
   ```

### Option 3: Railway

Railway is a modern platform that makes deployment simple.

1. Create an account at [https://railway.app](https://railway.app)
2. Create a new project and select "Deploy from GitHub"
3. Connect your GitHub repository with the application files
4. Add the environment variable `GROQ_API_KEY` with your API key
5. Set the start command to `streamlit run streamlit_app.py --server.port=$PORT --server.address=0.0.0.0`

### Option 4: Render

Render is another excellent platform for Streamlit applications.

1. Create an account at [https://render.com](https://render.com)
2. Create a new Web Service and select your GitHub repository
3. Set the build command to `pip install -r requirements.txt`
4. Set the start command to `streamlit run streamlit_app.py --server.port=$PORT --server.address=0.0.0.0`
5. Add the environment variable `GROQ_API_KEY` with your API key

## Local Testing Before Deployment

To test the application locally before deployment:

1. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```
2. Set your API key:
   ```
   export GROQ_API_KEY=your-api-key
   ```
3. Run the application:
   ```
   streamlit run streamlit_app.py
   ```

## Troubleshooting

- **API Key Issues**: Ensure your Groq API key is correctly set as an environment variable
- **Dependencies**: Make sure all dependencies in requirements.txt are compatible with your chosen platform
- **Port Configuration**: Some platforms require specific port configurations, which are handled in the Procfile

## Security Considerations

- Never commit your API key directly to your repository
- Always use environment variables or secrets management for sensitive information
- Consider setting up rate limiting if your application will be used by many users

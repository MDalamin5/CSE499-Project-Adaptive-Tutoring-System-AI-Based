import streamlit as st

st.set_page_config(
    page_title="Adaptive Math Tutor",
    page_icon="🧮",
    layout="wide"
)

st.title("Welcome to the Adaptive Math Tutor")

st.markdown("""
## An Interactive Step-by-Step Math Learning Experience

The Adaptive Math Tutor is designed to help students learn mathematics through guided problem-solving. 
Unlike traditional tutoring systems that provide complete solutions, this tutor offers step-by-step hints 
and adapts to your understanding level.

### Key Features:

- **Step-by-Step Guidance**: Receive one hint at a time to solve problems independently
- **Adaptive Feedback**: The system analyzes your responses and adjusts its guidance accordingly
- **Interactive Learning**: Engage in a conversation-like experience with the tutor
- **Progressive Hint System**: Get more detailed hints if you're struggling with a concept

### How to Use:

1. Configure your API key in the setup page (if you haven't already)
2. Navigate to the "Adaptive Math Tutor" page from the sidebar
3. Enter a math problem to begin
4. Respond to each hint to progress through the solution

### Example Problems to Try:

- Solve quadratic equations (e.g., x² + 5x + 6 = 0)
- Simplify algebraic expressions (e.g., 2(x + 3) - 4(2x - 1))
- Solve systems of linear equations
- Find derivatives of functions (for calculus)
- Evaluate integrals (for calculus)

### Get Started:

Click on "Adaptive Math Tutor" in the sidebar to begin your learning journey!
""")

st.sidebar.success("Select a page above.")

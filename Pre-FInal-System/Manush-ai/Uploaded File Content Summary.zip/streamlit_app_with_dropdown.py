import streamlit as st
import os
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

# Get the API key from environment variables or use a default placeholder
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

# Create a .env file with the API key
def save_api_key(api_key):
    with open(".env", "w") as f:
        f.write(f"GROQ_API_KEY={api_key}")
    os.environ["GROQ_API_KEY"] = api_key
    st.success("API key saved successfully!")
    st.rerun()

# Set page config
st.set_page_config(
    page_title="Adaptive Math Tutor",
    page_icon="🧮",
    layout="wide"
)

# Main app
st.title("Adaptive Math Tutor - Configuration")

# API key input
st.header("API Key Configuration")
st.write("To use this application, you need to provide a Groq API key.")

# Check if API key is already set
if GROQ_API_KEY:
    st.success("API key is configured!")
    if st.button("Change API Key"):
        # If user wants to change the key, show the input field
        new_api_key = st.text_input("Enter your Groq API key:", type="password")
        if new_api_key and st.button("Save New API Key"):
            save_api_key(new_api_key)
else:
    # If no API key is set, show the input field
    api_key = st.text_input("Enter your Groq API key:", type="password")
    if api_key and st.button("Save API Key"):
        save_api_key(api_key)

# Instructions
st.header("Instructions")
st.write("""
1. Get a Groq API key from [https://console.groq.com/](https://console.groq.com/)
2. Enter your API key in the field above and click 'Save API Key'
3. Once configured, you'll be able to use the Adaptive Math Tutor
""")

# Welcome message and features
st.header("Welcome to the Adaptive Math Tutor")

st.markdown("""
## An Interactive Step-by-Step Math Learning Experience

The Adaptive Math Tutor is designed to help students learn mathematics through guided problem-solving. 
Unlike traditional tutoring systems that provide complete solutions, this tutor offers step-by-step hints 
and adapts to your understanding level.

### Key Features:

- **Step-by-Step Guidance**: Receive one hint at a time to solve problems independently
- **Adaptive Feedback**: The system analyzes your responses and adjusts its guidance accordingly
- **Interactive Learning**: Engage in a conversation-like experience with the tutor
- **Progressive Hint System**: Get more detailed hints if you're struggling with a concept
- **Tutor Reasoning**: Expand the dropdown to see the tutor's reasoning behind each hint

### How to Use:

1. Configure your API key above (if you haven't already)
2. Navigate to the "Adaptive Math Tutor with Dropdown" page from the sidebar
3. Enter a math problem to begin
4. Respond to each hint to progress through the solution
5. Click "See tutor's reasoning" to view the thought process behind each hint

### Example Problems to Try:

- Solve quadratic equations (e.g., x² + 5x + 6 = 0)
- Simplify algebraic expressions (e.g., 2(x + 3) - 4(2x - 1))
- Solve systems of linear equations
- Find derivatives of functions (for calculus)
- Evaluate integrals (for calculus)
""")

# Link to the main application
if GROQ_API_KEY:
    st.header("Start Using the Tutor")
    st.write("Your API key is configured. You can now start using the Adaptive Math Tutor.")
    if st.button("Launch Adaptive Math Tutor"):
        # Redirect to the main application
        st.switch_page("pages/adaptive_math_tutor_with_dropdown.py")
